package com.inter.design;

public interface TypeCheck {

	//T findType
}
