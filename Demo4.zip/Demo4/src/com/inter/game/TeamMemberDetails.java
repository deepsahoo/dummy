package com.inter.game;

public class TeamMemberDetails {

	private String teamName;
	private int numberOfMbr;
	
	
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public int getNumberOfMbr() {
		return numberOfMbr;
	}
	public void setNumberOfMbr(int numberOfMbr) {
		this.numberOfMbr = numberOfMbr;
	}
	
	
}
