package com.inter.game;

import java.util.List;

public class Zone {
	

	private int zoneId;
	private List<TeamMemberDetails> mbrDetls;

	public List<TeamMemberDetails> getMbrDetls() {
		return mbrDetls;
	}

	public void setMbrDetls(List<TeamMemberDetails> mbrDetls) {
		this.mbrDetls = mbrDetls;
	}
	
	public int getZoneId() {
		return zoneId;
	}

	public void setZoneId(int zoneId) {
		this.zoneId = zoneId;
	}

}
