package com.inter.game;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class PlayGame {
	
	private static final String POSSIBLE = "POSSIBLE";
	private static final String IMPOSSIBLE = "IMPOSSIBLE";
	

	public static void main(String[] args) {

		List<Zone> zoneList = new ArrayList<Zone>();
		Scanner scan = new Scanner(System.in);
		int numberOfGame = scan.nextInt();
		for (int i = 0; i < numberOfGame; i++) {
			int numberOfTeam = scan.nextInt();
			for (int j = 0; j < numberOfTeam; i++) {
				String znConf = scan.nextLine();
				Zone zone = new Zone();
				zone.setZoneId(j);
				List<String> mbrConf = Arrays.asList(znConf.split(" ")); 

				for (int m = 0; m < mbrConf.size(); m++) {
					TeamMemberDetails mbrDetl = new TeamMemberDetails();
					mbrDetl.setTeamName("T" + m);
					mbrDetl.setNumberOfMbr(Integer.parseInt(mbrConf.get(m)));
					if (zone.getMbrDetls().isEmpty()) {
						List<TeamMemberDetails> mbrLst = new ArrayList<TeamMemberDetails>();
						mbrLst.add(mbrDetl);
						zone.setMbrDetls(mbrLst);
					} else {
						zone.getMbrDetls().add(mbrDetl);
					}
				}
				zoneList.add(zone);

			}
		}
		scan.close();

	}

	static String isSwapPossible(List<Zone> zoneList) {
		String posStr = new String();
		for (Zone zone : zoneList) {
			Zone currentZone = zone; // const Z1
			for (TeamMemberDetails mbrDetl : zone.getMbrDetls()) {
				TeamMemberDetails currentTeam = mbrDetl;//const T1
				for (TeamMemberDetails otherMbrDetl : zone.getMbrDetls()) {
					int equiMbr = 0;
					if (currentTeam.getTeamName().equals(otherMbrDetl.getTeamName())) {
						continue;
					}
					if (!currentTeam.getTeamName().equals(otherMbrDetl.getTeamName())) {//T2
						for (Zone Otherzone : zoneList) {
							if (currentZone.getZoneId() != Otherzone.getZoneId()) {//z2
								int currentMbrNo = Otherzone.getMbrDetls().stream()
										.filter(md -> md.getTeamName().equals(currentTeam.getTeamName())).findFirst()
										.get().getNumberOfMbr();// number of T1 -> 1
								int otherMbrNo = Otherzone.getMbrDetls().stream()
										.filter(md -> !md.getTeamName().equals(currentTeam.getTeamName())).findFirst()
										.get().getNumberOfMbr(); // number of T2 -> 1
								equiMbr += Math.min(currentMbrNo, otherMbrNo);
							}
						}
					}
					if (equiMbr == otherMbrDetl.getNumberOfMbr()) {
						posStr = POSSIBLE;
					} else {
						posStr = IMPOSSIBLE;
					}

				}
			}
		}
		return posStr;
	}

}
