package com.inter.design;

public class StringTypeCheck {

	public boolean isStrig(Object obj ) {
		//TODO : core logic goes here
		return true;
	}
}
