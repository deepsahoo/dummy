package com.inter.design;

import java.util.function.Supplier;

public class StringTypeSupplier implements Supplier<StringTypeCheck> {

	@Override
	public StringTypeCheck get() {
		return new StringTypeCheck();
	}

}
