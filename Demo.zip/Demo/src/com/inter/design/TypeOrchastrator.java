package com.inter.design;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

public class TypeOrchastrator extends StringTypeCheck{

	
	  public static Map<String, Supplier<Object>> map = new HashMap();
	  
	  { map.put("STRING", new StringTypeSupplier()); }
	  
	  public void register(String type,Supplier<Object>) {
	  
	  }
	  
	  public Supplier createTypeReference(String type) { map.get(type); }
	 
	
	

}
